<?php
/* Smarty version 3.1.33, created on 2019-04-03 03:04:25
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\jqueryScripts.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca40699b0fbb1_06463358',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e4219bd5141cabceed4cbe5b16e17f246c976061' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\jqueryScripts.tpl',
      1 => 1554253464,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca40699b0fbb1_06463358 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '12860258765ca40699b0dc64_19864363';
?>

<?php echo '<script'; ?>
>
    
    $('.ajaxForm').submit(function (e) {
        e.preventDefault();
        const form = $(this);
        $("#" + form.data('loader')).show();
        AjaxLoading(form.data("loader"));
        AjaxPost(form.data("url"), form.serialize(), function (data) {
            let msg = data['message'];
            if (data['state'] == 'success') {
                msg = "<div class='message alert alert-success alert-dismissible'>" + data['message'] + "</div>";

                if (form.data("url").indexOf('signinConfirm') > 0)
                    setTimeout(function (e) {
                        location.reload();
                    }, 2000);
            }
            $("#" + form.data("loader")).html(msg);

            setTimeout(function (e) {
                $("#" + form.data("loader")).hide();
            }, 10000);
            return false;
        });
        RemoveAjaxLoader(form.data("loader"));
        return false;
    });
    
<?php echo '</script'; ?>
><?php }
}
