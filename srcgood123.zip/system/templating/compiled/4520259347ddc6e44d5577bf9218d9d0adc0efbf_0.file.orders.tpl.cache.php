<?php
/* Smarty version 3.1.33, created on 2019-04-03 09:10:30
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\userpanel\orders.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca45c660abbf7_38813478',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4520259347ddc6e44d5577bf9218d9d0adc0efbf' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\userpanel\\orders.tpl',
      1 => 1554275408,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca45c660abbf7_38813478 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '6944475355ca45c660a7a40_83188434';
?>


<table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid"
       aria-describedby="dataTable_info" style="width: 100%;">
    <thead>
    <tr role="row">
        <th class="sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending"
            aria-label="#: activate to sort column descending" style="width: 220px;">#
        </th>
        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="Date: activate to sort column ascending" style="width: 328px;">DATE
        </th>
        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="Client Name: activate to sort column ascending" style="width: 164px;">CLIENT NAME
        </th>
        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="TEST NAME: activate to sort column ascending" style="width: 78px;">TEST NAME
        </th>
        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="PHONE NUMBER: activate to sort column ascending" style="width: 150px;">PHONE NUMBER
        </th>
        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="ACTION: activate to sort column ascending" style="width: 114px;">ACTION
        </th>
    </tr>
    </thead>
    <tbody>
    <tr role="row" class="even">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ordersData']->value, 'order');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['order']->value) {
?>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['id'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['order_date'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['clientname'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['testname'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['phone_number'];?>
</td>
            <td>
                <button class="btn btn-danger">ABORT</button>
            </td>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tr>
    </tbody>
</table><?php }
}
