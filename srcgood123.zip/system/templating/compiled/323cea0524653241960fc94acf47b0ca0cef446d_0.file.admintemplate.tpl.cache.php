<?php
/* Smarty version 3.1.33, created on 2019-04-04 06:32:19
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\template\admintemplate.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca588d3b54b84_25669877',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '323cea0524653241960fc94acf47b0ca0cef446d' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\template\\admintemplate.tpl',
      1 => 1554352147,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admincp/template/head.tpl' => 1,
    'file:admincp/template/header.tpl' => 1,
    'file:admincp/template/footer.tpl' => 1,
  ),
),false)) {
function content_5ca588d3b54b84_25669877 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->compiled->nocache_hash = '10324376785ca588d3b4fa32_86205616';
?>


<!DOCTYPE html>
<html lang="en">

<?php echo '/*%%SmartyNocache:10324376785ca588d3b4fa32_86205616%%*/<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>/*/%%SmartyNocache:10324376785ca588d3b4fa32_86205616%%*/';?>


<body class="fixed-nav sticky-footer" id="page-top">

<?php echo '/*%%SmartyNocache:10324376785ca588d3b4fa32_86205616%%*/<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>/*/%%SmartyNocache:10324376785ca588d3b4fa32_86205616%%*/';?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2976625325ca588d3b53d53_20137379', "content");
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13184013825ca588d3b543a2_85968865', "footer");
?>

</body>

</html>
<?php }
/* {block "content"} */
class Block_2976625325ca588d3b53d53_20137379 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_2976625325ca588d3b53d53_20137379',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_13184013825ca588d3b543a2_85968865 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_13184013825ca588d3b543a2_85968865',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->cached->hashes['10324376785ca588d3b4fa32_86205616'] = true;
?>

    <?php echo '/*%%SmartyNocache:10324376785ca588d3b4fa32_86205616%%*/<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>/*/%%SmartyNocache:10324376785ca588d3b4fa32_86205616%%*/';?>

<?php
}
}
/* {/block "footer"} */
}
