<?php
/* Smarty version 3.1.33, created on 2019-04-22 06:15:01
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\dashboard.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5cbd3fc5752757_64313192',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c3c1304baf6260bb020a55774416e4f89e884848' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\dashboard.tpl',
      1 => 1554385246,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5cbd3fc5752757_64313192 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15371213215cbd3fc5746163_01739733', "content");
?>




<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12066240795cbd3fc5751f77_89818057', "footer");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "admincp/template/admintemplate.tpl");
}
/* {block "content"} */
class Block_15371213215cbd3fc5746163_01739733 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_15371213215cbd3fc5746163_01739733',
  ),
);
public $nocache = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> ORDERS
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>DATE</th>
                                <th>CLIENT NAME</th>
                                <th>TEST NAME</th>
                                <th>PHONE NUMBER</th>
                                <th>ORDER STATE</th>
                                <th>ACTIONS</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>#</th>
                                <th>DATE</th>
                                <th>CLIENT NAME</th>
                                <th>TEST NAME</th>
                                <th>PHONE NUMBER</th>
                                <th>ORDER STATE</th>
                                <th>ACTIONS</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['orders']->value, 'order');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['order']->value) {
?>
                                <tr>
                                    <td><?php echo $_smarty_tpl->tpl_vars['order']->value['id'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['order']->value['order_date'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['order']->value['clientname'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['order']->value['testname'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['order']->value['phone_number'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['order']->value['order_state'];?>
</td>
                                    <td>
                                        <button class="btn btn-success btnDone" data-order="<?php echo $_smarty_tpl->tpl_vars['order']->value['id'];?>
">DONE</button>
                                        <button class="btn btn-danger btnAbort" data-order="<?php echo $_smarty_tpl->tpl_vars['order']->value['id'];?>
">ABORT</button>
                                    </td>
                                </tr>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- Update Modal-->
    <div class="modal fade" id="modalDONE" tabindex="-1" role="dialog" aria-labelledby="modalDONELabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalDONELabel">Update Order</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" class="ajaxForm" data-loader="orderLoader"
                      data-url="<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
adminOrderUpdate">
                    <div class="modal-body">
                        <div id="orderLoader"></div>

                        <input type="hidden" value="0" name="orderID" id="orderID">
                        <textarea id="orderMessage" name="orderMessage"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary btnUpdateOrder" type="submit">DONE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_12066240795cbd3fc5751f77_89818057 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_12066240795cbd3fc5751f77_89818057',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
>
        $(function () {
            $('#dataTable').DataTable();
            CKEDITOR.replace('orderMessage');

            $('#dataTable').on('draw.dt', function () {
                RegisterEvents();
            });

            // $('.btnUpdateOrder').on('click', function () {
            //
            // });

            RegisterEvents();

            function RegisterEvents() {
                $('.btnDone').on('click', function () {
                    let orderID = $(this).data("order");
                    $('#orderID').val(orderID);
                    $('#modalDONE').modal();
                });
            }
        });
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "footer"} */
}
