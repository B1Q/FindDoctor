<?php
/* Smarty version 3.1.33, created on 2019-04-03 23:14:54
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\template\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca5224e246dc2_33956249',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '405c3ce6cd967c0a4cd74f905e8281c34af12bc8' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\template\\footer.tpl',
      1 => 1554326092,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:template/jqueryScripts.tpl' => 1,
  ),
),false)) {
function content_5ca5224e246dc2_33956249 (Smarty_Internal_Template $_smarty_tpl) {
?>

<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>© <?php echo date('Y');?>
 <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</small>
        </div>
    </div>
</footer>
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="/logout">Logout</a>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap core JavaScript-->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/jquery/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
<!-- Core plugin JavaScript-->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/jquery-easing/jquery.easing.min.js"><?php echo '</script'; ?>
>
<!-- Page level plugin JavaScript-->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/datatables/jquery.dataTables.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/datatables/dataTables.bootstrap4.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/jquery.selectbox-0.2.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/retina-replace.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/jquery.magnific-popup.min.js"><?php echo '</script'; ?>
>
<!-- Custom scripts for all pages-->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/js/admin.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/js/ckeditor/ckeditor.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['jsPath']->value;?>
custom.js"><?php echo '</script'; ?>
>


<?php $_smarty_tpl->_subTemplateRender("file:template/jqueryScripts.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
