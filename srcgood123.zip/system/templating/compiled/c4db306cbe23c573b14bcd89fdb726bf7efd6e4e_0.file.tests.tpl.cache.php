<?php
/* Smarty version 3.1.33, created on 2019-04-04 16:21:51
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\tests.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca612ff83ec76_02644880',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c4db306cbe23c573b14bcd89fdb726bf7efd6e4e' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\tests.tpl',
      1 => 1554387710,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca612ff83ec76_02644880 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->compiled->nocache_hash = '10722321405ca612ff834c68_46139129';
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8283564965ca612ff838ab0_45887536', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2218221135ca612ff83e472_76334748', "footer");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "admincp/template/admintemplate.tpl");
}
/* {block "content"} */
class Block_8283564965ca612ff838ab0_45887536 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_8283564965ca612ff838ab0_45887536',
  ),
);
public $nocache = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->cached->hashes['10722321405ca612ff834c68_46139129'] = true;
?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> TESTS
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>NAME</th>
                                <th>PRICE</th>
                                <th>CATEGORIES</th>
                                <th>ACTION</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'tests\']->value, \'test\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'test\']->value) {
?>/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>

                                <tr>
                                    <td><?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'id\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
</td>
                                    <td><?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'name\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
</td>
                                    <td><?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'price\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
</td>
                                    <td><?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'category\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
</td>
                                    <td>
                                        <button class="btn btn-success btnEdit" data-test="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'id\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
"
                                                data-name="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'name\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
" data-price="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'price\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
"
                                                data-desc="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'description\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
">EDIT
                                        </button>
                                        <button class="btn btn-danger btnDelete" data-test="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'test\']->value[\'id\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
">DELETE
                                        </button>
                                    </td>
                                </tr>
                            <?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="box_form">
                <h3>Add Test</h3>
                <div id="addTestLoader"></div>
                <form method="post" class="ajaxForm" data-loader="addTestLoader"
                      data-url="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'siteurl\']->value;?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
adminAddTest" id="frmAddTest">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>NAME</label>
                                <input type="text" name="testName" id="frmTestName" class="form-control"
                                       placeholder="Test Name">
                            </div>
                            <div class="form-group">
                                <label>Price</label>
                                <input type="number" name="testPrice" id="frmtestPrice" class="form-control"
                                       placeholder="Price of this test">
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea id="testDescription" name="testDescription"></textarea>
                            </div>
                            <div class="form-group">
                                <label>ACTION</label><br>
                                <button class="btn btn-primary " style="width:30%" id="btnAddTest">Add Test
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Categories</label>
                                <select multiple class="form-control" style="height:400px" id="testCategories"
                                        name="testcategories[]">
                                    <?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'categories\']->value, \'cat\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'cat\']->value) {
?>/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>

                                        <option value="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'cat\']->value[\'id\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
"><?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'cat\']->value[\'name\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
</option>
                                    <?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>

                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- Update Modal-->
    <div class="modal fade" id="modalEDIT" tabindex="-1" role="dialog" aria-labelledby="modalEDITLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEDITLabel">EDIT TEST</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" class="ajaxForm" data-loader="updateLoader" id="editTestFrm"
                      data-url="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'siteurl\']->value;?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
adminUpdateTest">
                    <div class="modal-body">
                        <div id="updateLoader"></div>

                        <input type="hidden" value="0" name="edittestID" id="edittestID">
                        <div class="box_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>NAME</label>
                                        <input type="text" id="editTestName" name="editTestName" class="form-control"
                                               placeholder="Test Name">
                                    </div>
                                    <div class="form-group">
                                        <label>PRICE</label>
                                        <input type="number" id="editTestPrice" name="editTestPrice"
                                               class="form-control"
                                               placeholder="Test Price">
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea id="edittestDescription" name="edittestDescription"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Categories</label>
                                        <select multiple class="form-control" style="height:400px"
                                                id="edittestcategories"
                                                name="edittestcategories[]">
                                            <?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'categories\']->value, \'cat\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'cat\']->value) {
?>/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>

                                                <option value="<?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'cat\']->value[\'id\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
"><?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php echo $_smarty_tpl->tpl_vars[\'cat\']->value[\'name\'];?>
/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>
</option>
                                            <?php echo '/*%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>/*/%%SmartyNocache:10722321405ca612ff834c68_46139129%%*/';?>

                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary btnUpdateTest" type="submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_2218221135ca612ff83e472_76334748 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_2218221135ca612ff83e472_76334748',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
>
        $(function () {
            CKEDITOR.replace('testDescription');
            CKEDITOR.replace('edittestDescription');

            let dataTable = $('#dataTable').DataTable({
                "pageLength": 5,
                lengthMenu: [[5, 10], [5, 10]]
            });

            $('#dataTable').on('draw.dt', function () {
                RegisterEvents();
            });

            RegisterEvents();

            function RegisterEvents() {

                $('.btnEdit').on('click', function () {
                    let testID = $(this).data('test');
                    let testPrice = $(this).data('price');
                    let testName = $(this).data('name');
                    let desc = $(this).data('desc');

                    $('#edittestID').val(testID);
                    $('#editTestName').val(testName);
                    $('#editTestPrice').val(testPrice);
                    CKEDITOR.instances.edittestDescription.setData(desc);
                    $('#modalEDIT').modal();
                });


                $('#frmAddTest').bind('success', function (e, id) {
                    if ($(e).name == 'editTestFrm') return;
                    alert($(e).name);
                    let name = $('#frmTestName').val();
                    let price = $('#frmtestPrice').val();
                    let categories = $('#testCategories').find(':selected').text() || '';
                    let desc = $('#testDescription').val();

                    let buttons = '  <button class="btn btn-success btnEdit" data-test="' + id + '"\n' +
                        '                                                data-name="' + name + '" data-price="' + price + '"\n' +
                        '                                                data-desc="' + desc + '">EDIT\n' +
                        '                                        </button>\n' +
                        '                                        <button class="btn btn-danger btnDelete" data-test="' + id + '">DELETE\n' +
                        '                                        </button>'
                    dataTable.row.add([
                        id,
                        name,
                        price,
                        categories,
                        buttons
                    ]).draw(false);
                });
            }
        });
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "footer"} */
}
