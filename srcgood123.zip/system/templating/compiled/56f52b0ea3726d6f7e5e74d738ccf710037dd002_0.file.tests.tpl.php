<?php
/* Smarty version 3.1.33, created on 2019-04-05 18:40:49
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\cart\tests.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca7851179d3a1_91024975',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '56f52b0ea3726d6f7e5e74d738ccf710037dd002' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\cart\\tests.tpl',
      1 => 1554389624,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca7851179d3a1_91024975 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17149041195ca78511789166_81710049', "head");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12754735875ca7851178dcf2_76953549', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18844634645ca7851179ba46_06127000', "footer");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block "head"} */
class Block_17149041195ca78511789166_81710049 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_17149041195ca78511789166_81710049',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<?php
}
}
/* {/block "head"} */
/* {block "content"} */
class Block_12754735875ca7851178dcf2_76953549 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_12754735875ca7851178dcf2_76953549',
  ),
);
public $nocache = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <main>
        <div class="main_title">
            <h1><?php echo constant("TESTS_TITLE");?>
</h1>
        </div>

        <div class="box_form">
            <div class="row">
                <div class="col-md-2">
                    <h3>CATEGORY</h3>
                    <div class="form-group">
                        <select class="form-control" id="categorySelector">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['categories']->value, 'category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['category']->value) {
?>
                                <option name="<?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
</option>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0"
                           role="grid"
                           aria-describedby="dataTable_info" style="width: 100%;">
                        <thead>
                        <tr role="row">
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="TEST NAME: activate to sort column ascending" style="width: 180px;">TEST
                                NAME
                            </th>
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="REGULAR PRICE: activate to sort column ascending" style="width: 160px;">
                                PRICE
                            </th>
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="REGULAR PRICE: activate to sort column ascending" style="width: 160px;">
                                CATEGORIES
                            </th>
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="CART: activate to sort column ascending" style="width: 50px;">
                                CART
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                            <tr role="row" class="even">
                                <td><?php echo $_smarty_tpl->tpl_vars['test']->value['name'];?>
</td>
                                <td id="test<?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
" data-price="<?php echo $_smarty_tpl->tpl_vars['test']->value['price'];?>
"><?php echo $_smarty_tpl->tpl_vars['test']->value['price'];?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['test']->value['category'];?>
</td>
                                <td>
                                    <button id="test<?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
" data-name="<?php echo $_smarty_tpl->tpl_vars['test']->value['name'];?>
" class="btn btn-info cartBtn"
                                            data-test="<?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
">
                                        Add To Cart
                                    </button>
                                </td>
                            </tr>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-4">
                    <div class="box_general_3 booking">
                        <form>
                            <div class="title">
                                <h3>Your booking</h3>
                            </div>
                            <ul class="treatments checkout clearfix">
                                <?php if (count($_smarty_tpl->tpl_vars['cartData']->value) > 0) {?>
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cartData']->value, 'cartItem');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['cartItem']->value) {
?>
                                        <?php if (is_object($_smarty_tpl->tpl_vars['cartItem']->value)) {?>
                                            <li class="checkoutItem" data-cart="<?php echo $_smarty_tpl->tpl_vars['cartItem']->value->id;?>
">
                                                <?php echo $_smarty_tpl->tpl_vars['cartItem']->value->name;?>

                                                <a href="#"><i class="float-right removeItem icon-cancel"
                                                               data-id="<?php echo $_smarty_tpl->tpl_vars['cartItem']->value->id;?>
"></i></a>
                                                <strong class="float-right"><?php echo $_smarty_tpl->tpl_vars['cartItem']->value->price;?>
kd</strong>
                                            </li>
                                        <?php }?>
                                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                <?php }?>
                                <li class="total">
                                    Total <strong class="float-right" id="totalAmount"><?php echo $_smarty_tpl->tpl_vars['cartData']->value['total'];?>
 KD</strong>
                                </li>
                            </ul>
                            <hr>
                            <a href="#" id="btnRequestTest" class="btn_1 full-width">Request tests</a>
                        </form>
                    </div>
                    <!-- /box_general -->
                </div>
            </div>
        </div>
    </main>
<?php
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_18844634645ca7851179ba46_06127000 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_18844634645ca7851179ba46_06127000',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/vendor/datatables/jquery.dataTables.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/vendor/datatables/dataTables.bootstrap4.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        $(document).ready(function () {
            let table = $('#dataTable').DataTable({
                "pageLength": 5,
                lengthMenu: [[5, 10], [5, 10]]
            });

            RegisterEvents();
            ClearShit();

            $('#dataTable').on('draw.dt', function () {
                RegisterEvents();
                ClearShit();
            });

            $('#categorySelector').on('change', function () {
                table.search($(this).find("option:selected").text());
                table.draw();
            });

            $('#btnRequestTest').on('click', function () {
                AjaxPost('<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
checkout', '', function (data) {
                    let responseCode = data['state'];
                    if (responseCode == 'success') {
                        window.location.href = data['message'];
                    }
                    else
                        alert(data['message']);
                });
                return false;
            });
        });

        function ClearShit() {
            $('.checkoutItem').each(function (e) {
                $('button[data-test="' + $(this).data("cart") + '"]').addClass("disabled");
            });
        }

        function RegisterEvents() {
            $('.cartBtn').off('click');
            $('.cartBtn').on('click', function (e) {
                if ($(this).hasClass("disabled")) return;
                let itemId = $(this).data('test');
                let itemName = $(this).data("name")
                let itemPrice = $('#test' + itemId).data("price");
                let element = $(this);
                
                let itemData = {itemID: itemId}
                

                AjaxPost('<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
addtocart', itemData, function (data) {
                    let responseCode = data['state'];
                    if (responseCode != 'error') {
                        let responseMsg = data['message'];
                        let elementToAdd = "           <li class=\"checkoutItem\" data-cart=" + itemId + ">\n" +
                            "                               " + responseMsg['item']['name'] + "\n" +
                            "                            <a href=\"#\"><i class=\"float-right removeItem icon-cancel\"\n" +
                            "                        data-id=" + itemId + "></i></a>\n" +
                            "                        <strong class=\"float-right\">" + responseMsg['item']['price'] + " KD</strong>\n" +
                            "                            </li>"
                        $('.checkout > .total').before(elementToAdd);
                        // $('.checkout > .total').before("<li>" + responseMsg['item']['name'] + " " +
                        //     "<strong class='float-right'>" + responseMsg['item']['price'] + " KD</strong></li>");
                        $('#totalAmount').html(responseMsg['total'] + " KD");
                        element.addClass('disabled');
                        RegisterEvents();
                    }
                    else
                        alert("Something went wrong while trying to add an item to the cart!");
                });
            });

            $('.removeItem').off('click');
            $('.removeItem').on('click', function (e) {
                
                let itemData = {itemID: $(this).data("id")};
                
                AjaxPost('<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
removefromcart', itemData, function (data) {
                    let responseCode = data['state'];

                    if (responseCode === 'success') {
                        let responseMsg = data['message'];
                        let element = $("#item" + responseMsg['item']);
                        let listElement = $("li[data-cart='" + responseMsg['item'] + "']");

                        element.removeClass('disabled');
                        listElement.remove();
                        $('#totalAmount').html(responseMsg['total'] + " KD");
                    }
                });
                return false;
            });
        }


    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "footer"} */
}
