<?php
/* Smarty version 3.1.33, created on 2019-04-03 03:32:12
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca40d1c5bac52_15774415',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'be54d67ee937ca5518609d66be998b7633242f4b' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\footer.tpl',
      1 => 1554255114,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:template/jqueryScripts.tpl' => 1,
  ),
),false)) {
function content_5ca40d1c5bac52_15774415 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '19483033845ca40d1c5b5019_92739095';
?>

<footer>
    <div class="container margin_60_35">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <p>
                    <a href="index.html" title="Findoctor">
                        <img src="<?php echo $_smarty_tpl->tpl_vars['imgPath']->value;?>
/logo.png" data-retina="true" alt="" width="163" height="36"
                             class="img-fluid">
                    </a>
                </p>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5><?php echo constant("FOOTER_ABOUT");?>
</h5>
                <ul class="links">
                    <li><a href="#0"><?php echo constant("FOOTER_ABOUTUS");?>
</a></li>
                    <li><a href="blog.html"><?php echo constant("FOOTER_BLOG");?>
</a></li>
                    <li><a href="#0"><?php echo constant("FOOTER_FAQ");?>
</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5><?php echo constant("FOOTER_USEFUL_LINKS");?>
</h5>
                <ul class="links">
                    <li><a href="#0"><?php echo constant("FOOTER_DOCTORS");?>
</a></li>
                    <li><a href="#0"><?php echo constant("FOOTER_CLINICS");?>
</a></li>
                    <li><a href="#0"><?php echo constant("FOOTER_SPECIALIZATION");?>
</a></li>
                    <li><a href="signup"><?php echo constant("FOOTER_JOIN_AS_DOCTOR");?>
</a></li>
                    <li><a href="#0"><?php echo constant("FOOTER_DOWNLOADAPP");?>
</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5>Contact with Us</h5>
                <ul class="contacts">
                    <li><a href="tel://<?php echo $_smarty_tpl->tpl_vars['contact']->value['mobile'];?>
"><i class="icon_mobile"></i> <?php echo $_smarty_tpl->tpl_vars['contact']->value['mobile'];?>
</a></li>
                    <li><a href="mailto:<?php echo $_smarty_tpl->tpl_vars['contact']->value['email'];?>
"><i class="icon_mail_alt"></i> <?php echo $_smarty_tpl->tpl_vars['contact']->value['email'];?>
</a></li>
                </ul>
                <div class="follow_us">
                    <h5>Follow us</h5>
                    <ul>
                        <li><a target='_blank' href="<?php echo $_smarty_tpl->tpl_vars['socialmedia']->value['facebook'];?>
"target='_blank' ><i class="social_facebook"></i></a></li>
                        <li><a target='_blank' href="<?php echo $_smarty_tpl->tpl_vars['socialmedia']->value['twitter'];?>
"><i class="social_twitter"></i></a></li>
                        <li><a target='_blank' href="<?php echo $_smarty_tpl->tpl_vars['socialmedia']->value['linkedin'];?>
"><i class="social_linkedin"></i></a></li>
                        <li><a target='_blank' href="<?php echo $_smarty_tpl->tpl_vars['socialmedia']->value['instagram'];?>
"><i class="social_instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!--/row-->
        <hr>
        <div class="row">
            <div class="col-md-8">
                <ul id="additional_links">
                    <li><a href="#0">Terms and conditions</a></li>
                    <li><a href="#0">Privacy</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <div id="copy">© <?php echo date('Y');?>
 <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</div>
            </div>
        </div>
    </div>
</footer>
<!--/footer-->

<div id="toTop"></div>
<!-- Back to top button -->

<!-- COMMON SCRIPTS -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['jsPath']->value;?>
jquery-2.2.4.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['jsPath']->value;?>
common_scripts.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['jsPath']->value;?>
functions.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['jsPath']->value;?>
custom.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" async><?php echo '</script'; ?>
>

<!-- Scripts -->
<?php $_smarty_tpl->_subTemplateRender("file:template/jqueryScripts.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
