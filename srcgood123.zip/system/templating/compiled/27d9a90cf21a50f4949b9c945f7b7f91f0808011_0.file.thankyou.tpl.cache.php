<?php
/* Smarty version 3.1.33, created on 2019-04-04 16:54:53
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\thankyou.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca61abd96e198_65868667',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '27d9a90cf21a50f4949b9c945f7b7f91f0808011' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\thankyou.tpl',
      1 => 1554388857,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca61abd96e198_65868667 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->compiled->nocache_hash = '1452320725ca61abd969270_03054135';
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7642578295ca61abd96c9c7_17874418', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block 'content'} */
class Block_7642578295ca61abd96c9c7_17874418 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_7642578295ca61abd96c9c7_17874418',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <main>
        <div class="container margin_120">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div id="confirm">
                        <div class="icon icon--order-success svg add_bottom_15">
                            <svg xmlns="http://www.w3.org/2000/svg" width="72" height="72">
                                <g fill="none" stroke="#8EC343" stroke-width="2">
                                    <circle cx="36" cy="36" r="35"
                                            style="stroke-dasharray:240px, 240px; stroke-dashoffset: 480px;"></circle>
                                    <path d="M17.417,37.778l9.93,9.909l25.444-25.393"
                                          style="stroke-dasharray:50px, 50px; stroke-dashoffset: 0px;"></path>
                                </g>
                            </svg>
                        </div>
                        <h2><?php echo constant("THANKYOU_TITLE");?>
</h2>
                        <p><?php echo constant("THANKYOU_MAIL");?>
 <?php echo $_smarty_tpl->tpl_vars['mail']->value;?>
</p>
                    </div>
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </main>
    <!-- /main -->
<?php
}
}
/* {/block 'content'} */
}
