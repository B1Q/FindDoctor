<?php
/* Smarty version 3.1.33, created on 2019-04-04 16:07:54
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\signup.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca60fba5c5391_35153679',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c9fbd1706462cf9a830f45356e752735b18f88f1' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\signup.tpl',
      1 => 1554265769,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca60fba5c5391_35153679 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->compiled->nocache_hash = '17129205025ca60fba5bdc35_07793773';
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11941530025ca60fba5c1099_67795013', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block 'content'} */
class Block_11941530025ca60fba5c1099_67795013 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_11941530025ca60fba5c1099_67795013',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <main>
        <div class="bg_color_2">
            <div class="container margin_60_35">
                <div id="register">
                    <h1>Please register to Findoctor!</h1>
                    <div class="row justify-content-center">
                        <div class="col-md-5">
                            <form method="post" class="ajaxForm"
                                  data-loader="signUploader"
                                  data-url="<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
signupConfirm">
                                <div class="box_form">
                                    <div id="signUploader" style="display: none">

                                    </div>
                                    <div class="form-group">
                                        <label><?php echo constant("SIGNUP_NAME");?>
</label>
                                        <input type="text" name="firstName" class="form-control"
                                               placeholder="<?php echo constant("SIGNUP_NAME");?>
">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo constant("SIGNUP_LASTNAME");?>
</label>
                                        <input type="text" name="lastName" class="form-control"
                                               placeholder="<?php echo constant("SIGNUP_NAME");?>
">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo constant("SIGNUP_EMAIL");?>
</label>
                                        <input type="email" name="email" class="form-control"
                                               placeholder="<?php echo constant("SIGNUP_NAME");?>
">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo constant("SIGNUP_PASSWORD");?>
</label>
                                        <input type="password" name="password" class="form-control" id="password1"
                                               placeholder="<?php echo constant("SIGNUP_PASSWORD");?>
">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo constant("SIGNUP_PASSWORD_CONFIRM");?>
</label>
                                        <input type="password" name="password_confirm" class="form-control"
                                               id="password2"
                                               placeholder="<?php echo constant("SIGNUP_PASSWORD_CONFIRM");?>
">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo constant("SIGNUP_PHONE");?>
</label>
                                        <input type="text" name="phone_number" class="form-control" id="phoneNumber"
                                               placeholder="<?php echo constant("SIGNUP_PHONE");?>
">
                                    </div>
                                    <div id="pass-info" class="clearfix"></div>
                                    <div class="form-group text-center add_top_30">
                                        <button class="btn_1" type="submit"><?php echo constant("SIGNUP_SUBMIT");?>
</button>
                                    </div>
                                </div>
                                                                                                                                                                                            </form>
                        </div>
                    </div>
                    <!-- /row -->
                </div>
                <!-- /register -->
            </div>
        </div>
    </main>
    <!-- /main -->
<?php
}
}
/* {/block 'content'} */
}
