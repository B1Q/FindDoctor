<?php
/* Smarty version 3.1.33, created on 2019-04-03 09:20:40
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\maintemplate.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca45ec873ff53_45278304',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '9890d898631b3932df3052a538a1a36de60dddb2' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\maintemplate.tpl',
      1 => 1554276038,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:template/head.tpl' => 1,
    'file:template/header.tpl' => 1,
    'file:template/footer.tpl' => 1,
  ),
),false)) {
function content_5ca45ec873ff53_45278304 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->compiled->nocache_hash = '10646884265ca45ec873ba92_49595166';
?>

<!DOCTYPE html>
<html lang="en">

<?php $_smarty_tpl->_subTemplateRender("file:template/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body>

<?php echo '/*%%SmartyNocache:10646884265ca45ec873ba92_49595166%%*/<?php $_smarty_tpl->_subTemplateRender("file:template/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>/*/%%SmartyNocache:10646884265ca45ec873ba92_49595166%%*/';?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11638876795ca45ec873f127_45170009', "content");
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3133411555ca45ec873f762_59042997', "footer");
?>

</body>

</html>
<?php }
/* {block "content"} */
class Block_11638876795ca45ec873f127_45170009 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_11638876795ca45ec873f127_45170009',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_3133411555ca45ec873f762_59042997 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_3133411555ca45ec873f762_59042997',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->cached->hashes['10646884265ca45ec873ba92_49595166'] = true;
?>

    <?php echo '/*%%SmartyNocache:10646884265ca45ec873ba92_49595166%%*/<?php $_smarty_tpl->_subTemplateRender("file:template/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>/*/%%SmartyNocache:10646884265ca45ec873ba92_49595166%%*/';?>

<?php
}
}
/* {/block "footer"} */
}
