<?php
/* Smarty version 3.1.33, created on 2019-04-03 04:22:18
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca418da37a2d6_77758190',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e8deb8749bd9cba88a4382196bf46ab454470de8' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\header.tpl',
      1 => 1554258137,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca418da37a2d6_77758190 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '3972265735ca418da375ae7_13382399';
?>

<div class="layer"></div>
<!-- Mobile menu overlay mask -->

<div id="preloader">
    <div data-loader="circle-side"></div>
</div>
<!-- End Preload -->

<header class="header_sticky">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div id="logo_home">
                    <h1><a href="/" title="<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</a></h1>
                </div>
            </div>
            <nav class="col-lg-9 col-6">
                <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile</span></a>
                <ul id="top_access">
                    <?php if ($_smarty_tpl->tpl_vars['sessionId']->value == 0) {?>
                        <li><a href="/control"><i class="pe-7s-user"></i></a></li>
                        <li><a href="/signup"><i class="pe-7s-add-user"></i></a></li>
                    <?php } else { ?>
                        <li><a href="/logout"><i class="icon-logout-3" data-tooltip="Logout!"></i></a></li>
                    <?php }?>
                </ul>
                <div class="main-menu">
                    <ul>
                        <li>
                            <a href="/"><?php echo constant("UI_HOME");?>
</a>
                        </li>
                        <li>
                            <a href="/about"><?php echo constant("UI_ABOUTUS");?>
</a>
                        </li>
                        <li>
                            <a href="/test"><?php echo constant("UI_TESTS");?>
</a>
                        </li>
                        <li><a href="/contact"><?php echo constant("UI_CONTACT");?>
</a></li>
                    </ul>
                </div>
                <!-- /main-menu -->
            </nav>
        </div>
    </div>
    <!-- /container -->
</header>
<!-- /header --><?php }
}
