<?php
/* Smarty version 3.1.33, created on 2019-04-04 19:49:02
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\userpanel\orders.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca6438e747885_47795482',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4520259347ddc6e44d5577bf9218d9d0adc0efbf' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\userpanel\\orders.tpl',
      1 => 1554400138,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca6438e747885_47795482 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\Programming\\WebDevelopment\\PHP\\FindDoctor\\src\\system\\templating\\smarty-3.1.33\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>


<table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid"
       aria-describedby="dataTable_info" style="width: 100%;">
    <thead>
    <tr role="row">
        <th class="sorting_asc" aria-controls="dataTable"
            aria-label="#: activate to sort column descending" style="width: 80px;">#
        </th>
        <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="Date: activate to sort column ascending" style="width: 450px;"><?php echo constant("GENERAL_DATE");?>

        </th>
        <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="Client Name: activate to sort column ascending" style="width: 180px;"><?php echo constant("GENERAL_CLIENTNAME");?>

        </th>
        <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="TEST NAME: activate to sort column ascending" style="width: 160px;"><?php echo constant("GENERAL_TESTNAME");?>

        </th>
        <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="PHONE NUMBER: activate to sort column ascending" style="width: 180px;"><?php echo constant("GENERAL_PHONENUMBER");?>

        </th>
        <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
            aria-label="ACTION: activate to sort column ascending" style="width: 114px;"><?php echo constant("GENERAL_ACTION");?>

        </th>
    </tr>
    </thead>
    <tbody>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ordersData']->value, 'order');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['order']->value) {
?>
        <tr role="row" class="even">
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['id'];?>
</td>
            <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['order']->value['order_date'],"%a, %B %e, %Y %T");?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['clientname'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['testname'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['order']->value['phone_number'];?>
</td>
            <?php if (!$_smarty_tpl->tpl_vars['order']->value['aborted']) {?>
                <td>
                    <button data-killname="<?php echo $_smarty_tpl->tpl_vars['order']->value['testname'];?>
" data-killid="<?php echo $_smarty_tpl->tpl_vars['order']->value['id'];?>
" class="btn btn-danger btnAbort">
                        ABORT
                    </button>
                </td>
            <?php } else { ?>
                <td><span class="text-danger">ABORTED</span></td>
            <?php }?>
        </tr>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tbody>
</table>
<?php }
}
