<?php
/* Smarty version 3.1.33, created on 2019-04-04 20:04:36
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca647342fe755_28944324',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e8deb8749bd9cba88a4382196bf46ab454470de8' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\header.tpl',
      1 => 1554401073,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca647342fe755_28944324 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="layer"></div>
<!-- Mobile menu overlay mask -->

<div id="preloader">
    <div data-loader="circle-side"></div>
</div>
<!-- End Preload -->

<header class="header_sticky">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div id="logo_home">
                    <h1><a href="/" title="<?php echo $_smarty_tpl->tpl_vars['title']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</a></h1>
                </div>
            </div>
            <nav class="col-lg-9 col-6">
                <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span><?php echo constant("GENERAL_MOBILEMENU");?>
</span></a>
                <ul id="top_access">
                    <?php if ($_smarty_tpl->tpl_vars['sessionId']->value == 0) {?>
                        <li><a href="/control"><i class="pe-7s-user"></i></a></li>
                        <li><a href="/signup"><i class="pe-7s-add-user"></i></a></li>
                    <?php } else { ?>
                        <li><a href="/logout"><i class="icon-logout-3" data-tooltip="Logout!"></i></a></li>
                    <?php }?>
                </ul>
                <div class="main-menu">
                    <ul>
                        <li>
                            <a href="/"><?php echo constant("UI_HOME");?>
</a>
                        </li>
                        <li>
                            <a href="/about"><?php echo constant("UI_ABOUTUS");?>
</a>
                        </li>
                        <li>
                            <a href="/tests"><?php echo constant("UI_TESTS");?>
</a>
                        </li>
                        <li><a href="/contact"><?php echo constant("UI_CONTACT");?>
</a></li>
                        <?php if (isset($_smarty_tpl->tpl_vars['userProfile']->value['rank'])) {?>
                            <li><a href="/control"><?php echo constant("UI_CONTROLPANEL");?>
</a></li>
                            <?php if ($_smarty_tpl->tpl_vars['userProfile']->value['rank'] == 1) {?>
                                <li><a href="/admincp"><b><?php echo constant("GENERAL_ADMIN");?>
</b></a></li>
                            <?php }?>
                        <?php }?>

                        <li class="submenu">
                            <a href="#" onclick="return false;" class="show-submenu"><?php echo constant("UI_LANGUAGE");?>

                                <i class="icon-down-open-mini"></i></a>
                            <ul>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
?>
                                    <li>
                                        <a class='languageSwitch' data-key="<?php echo $_smarty_tpl->tpl_vars['language']->value['key'];?>
" href="#">
                                            <i class="<?php echo $_smarty_tpl->tpl_vars['language']->value['icon'];?>
"></i> <?php echo $_smarty_tpl->tpl_vars['language']->value['name'];?>

                                        </a>
                                    </li>
                                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- /main-menu -->
            </nav>
        </div>
    </div>
    <!-- /container -->
</header>
<!-- /header --><?php }
}
