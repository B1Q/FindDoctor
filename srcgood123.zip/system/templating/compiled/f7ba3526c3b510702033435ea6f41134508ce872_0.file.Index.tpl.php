<?php
/* Smarty version 3.1.33, created on 2019-04-04 19:51:17
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\Index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca6441526a2b1_39937348',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f7ba3526c3b510702033435ea6f41134508ce872' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\Index.tpl',
      1 => 1554255015,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca6441526a2b1_39937348 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4882584325ca64415268b82_07512965', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block 'content'} */
class Block_4882584325ca64415268b82_07512965 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_4882584325ca64415268b82_07512965',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<main>

        <div class="hero_home version_1">
        <div class="content">
            <h3>Find a Doctor!</h3>
            <p>
                Ridiculus sociosqu cursus neque cursus curae ante scelerisque vehicula.
            </p>
        </div>
    </div>
    <!-- /Hero -->

    <div class="container margin_120_95">
        <div class="main_title">
            <h2>Discover the <strong>online</strong> appointment!</h2>
            <p>Usu habeo equidem sanctus no. Suas summo id sed, erat erant oporteat cu pri. In eum omnes molestie. Sed
                ad debet scaevola, ne mel.</p>
        </div>
        <div class="row add_bottom_30">
            <div class="col-lg-4">
                <div class="box_feat" id="icon_1">
                    <span></span>
                    <h3>Find a Doctor</h3>
                    <p>Usu habeo equidem sanctus no. Suas summo id sed, erat erant oporteat cu pri. In eum omnes
                        molestie.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="box_feat" id="icon_2">
                    <span></span>
                    <h3>View profile</h3>
                    <p>Usu habeo equidem sanctus no. Suas summo id sed, erat erant oporteat cu pri. In eum omnes
                        molestie.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="box_feat" id="icon_3">
                    <h3>Book a visit</h3>
                    <p>Usu habeo equidem sanctus no. Suas summo id sed, erat erant oporteat cu pri. In eum omnes
                        molestie.</p>
                </div>
            </div>
        </div>
        <!-- /row -->
        <p class="text-center"><a href="list.html" class="btn_1 medium">Find Doctor</a></p>

    </div>
    <!-- /container -->

    <div class="bg_color_1">
        <div class="container margin_120_95">
            <div class="main_title">
                <h2>Most Viewed doctors</h2>
                <p>Usu habeo equidem sanctus no. Suas summo id sed, erat erant oporteat cu pri.</p>
            </div>
            <div id="reccomended" class="owl-carousel owl-theme">
                <div class="item">
                    <a href="detail-page.html">
                        <div class="views"><i class="icon-eye-7"></i>140</div>
                        <div class="title">
                            <h4>Dr. Julia Holmes<em>Pediatrician - Cardiologist</em></h4>
                        </div>
                        <img src="http://via.placeholder.com/350x500.jpg" alt="">
                    </a>
                </div>
                <div class="item">
                    <a href="detail-page.html">
                        <div class="views"><i class="icon-eye-7"></i>120</div>
                        <div class="title">
                            <h4>Dr. Julia Holmes<em>Pediatrician</em></h4>
                        </div>
                        <img src="http://via.placeholder.com/350x500.jpg" alt="">
                    </a>
                </div>
                <div class="item">
                    <a href="detail-page.html">
                        <div class="views"><i class="icon-eye-7"></i>115</div>
                        <div class="title">
                            <h4>Dr. Julia Holmes<em>Pediatrician</em></h4>
                        </div>
                        <img src="http://via.placeholder.com/350x500.jpg" alt="">
                    </a>
                </div>
                <div class="item">
                    <a href="detail-page.html">
                        <div class="views"><i class="icon-eye-7"></i>98</div>
                        <div class="title">
                            <h4>Dr. Julia Holmes<em>Pediatrician</em></h4>
                        </div>
                        <img src="http://via.placeholder.com/350x500.jpg" alt="">
                    </a>
                </div>
                <div class="item">
                    <a href="detail-page.html">
                        <div class="views"><i class="icon-eye-7"></i>98</div>
                        <div class="title">
                            <h4>Dr. Julia Holmes<em>Pediatrician</em></h4>
                        </div>
                        <img src="http://via.placeholder.com/350x500.jpg" alt="">
                    </a>
                </div>
            </div>
            <!-- /carousel -->
        </div>
        <!-- /container -->
    </div>
    <!-- /white_bg -->


    <div id="app_section">
        <div class="container">
            <div class="row justify-content-around">
                <div class="col-md-5">
                    <p><img src="<?php echo $_smarty_tpl->tpl_vars['imgPath']->value;?>
app_img.svg" alt="" class="img-fluid" width="500" height="433"></p>
                </div>
                <div class="col-md-6">
                    <small>Application</small>
                    <h3>Download <strong>Findoctor App</strong> Now!</h3>
                    <p class="lead">Tota omittantur necessitatibus mei ei. Quo paulo perfecto eu, errem percipit
                        ponderum no eos. Has eu mazim sensibus. Ad nonumes dissentiunt qui, ei menandri electram eos.
                        Nam iisque consequuntur cu.</p>
                    <div class="app_buttons wow" data-wow-offset="100">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                             x="0px" y="0px" viewBox="0 0 43.1 85.9" style="enable-background:new 0 0 43.1 85.9;"
                             xml:space="preserve">
							<path stroke-linecap="round" stroke-linejoin="round" class="st0 draw-arrow"
                                  d="M11.3,2.5c-5.8,5-8.7,12.7-9,20.3s2,15.1,5.3,22c6.7,14,18,25.8,31.7,33.1"/>
                            <path stroke-linecap="round" stroke-linejoin="round" class="draw-arrow tail-1"
                                  d="M40.6,78.1C39,71.3,37.2,64.6,35.2,58"/>
                            <path stroke-linecap="round" stroke-linejoin="round" class="draw-arrow tail-2"
                                  d="M39.8,78.5c-7.2,1.7-14.3,3.3-21.5,4.9"/>
						</svg>
                        <a href="#0" class="fadeIn"><img src="<?php echo $_smarty_tpl->tpl_vars['imgPath']->value;?>
apple_app.png" alt="" width="150" height="50"
                                                         data-retina="true"></a>
                        <a href="#0" class="fadeIn"><img src="<?php echo $_smarty_tpl->tpl_vars['imgPath']->value;?>
google_play_app.png" alt="" width="150"
                                                         height="50" data-retina="true"></a>
                    </div>
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /app_section -->
</main>
<!-- /main content -->
<?php
}
}
/* {/block 'content'} */
}
