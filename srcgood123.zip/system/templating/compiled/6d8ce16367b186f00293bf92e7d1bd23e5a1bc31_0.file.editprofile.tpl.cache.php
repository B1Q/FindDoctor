<?php
/* Smarty version 3.1.33, created on 2019-04-03 10:06:12
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\userpanel\editprofile.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca46974746499_83413212',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d8ce16367b186f00293bf92e7d1bd23e5a1bc31' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\userpanel\\editprofile.tpl',
      1 => 1554278771,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca46974746499_83413212 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '17233263475ca46974737ec1_04542405';
?>

<div class="row justify-content-center">
    <div class="col-md-12">
        <h3>EditProfile</h3>
        <form method="post" class="ajaxForm"
              data-loader="updateLoader"
              data-url="<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
updateProfile">
            <div class="box_form">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo constant("SIGNUP_NAME");?>
</label>
                            <input type="text" name="firstName" class="form-control"
                                   value="<?php echo $_smarty_tpl->tpl_vars['userProfile']->value['firstname'];?>
"
                                   placeholder="<?php echo constant("SIGNUP_NAME");?>
">
                        </div>
                        <div class="form-group">
                            <label><?php echo constant("SIGNUP_LASTNAME");?>
</label>
                            <input type="text" name="lastName" class="form-control"
                                   value="<?php echo $_smarty_tpl->tpl_vars['userProfile']->value['lastname'];?>
"
                                   placeholder="<?php echo constant("SIGNUP_NAME");?>
">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo constant("SIGNUP_EMAIL");?>
</label>
                            <input type="email" name="email" class="form-control"
                                   value="<?php echo $_smarty_tpl->tpl_vars['userProfile']->value['email'];?>
"
                                   placeholder="<?php echo constant("SIGNUP_NAME");?>
">
                        </div>
                        <div class="form-group">
                            <label><?php echo constant("SIGNUP_PHONE");?>
</label>
                            <input type="text" name="phone_number" class="form-control" id="phoneNumber"
                                   value="<?php echo $_smarty_tpl->tpl_vars['userProfile']->value['phone_number'];?>
"
                                   placeholder="<?php echo constant("SIGNUP_PHONE");?>
">
                        </div>
                    </div>
                </div>
                <div class="box_form">
                    <h3>Confirm your Identity</h3>
                    <div id="updateLoader" style="display: none">

                    </div>
                    <div class="form-group">
                        <label><?php echo constant("SIGNUP_PASSWORD");?>
</label>
                        <input type="password" name="password" class="form-control" id="password1"
                               placeholder="<?php echo constant("SIGNUP_PASSWORD");?>
">
                    </div>
                    <div class="form-group">
                        <label><?php echo constant("SIGNUP_PASSWORD_CONFIRM");?>
</label>
                        <input type="password" name="password_confirm" class="form-control"
                               id="password2"
                               placeholder="<?php echo constant("SIGNUP_PASSWORD_CONFIRM");?>
">
                    </div>
                </div>
                <div id="pass-info" class="clearfix"></div>
                <div class="form-group text-center add_top_30">
                    <button class="btn_1" type="submit"><?php echo constant("EDITPROFILE_SUBMIT");?>
</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- /row --><?php }
}
