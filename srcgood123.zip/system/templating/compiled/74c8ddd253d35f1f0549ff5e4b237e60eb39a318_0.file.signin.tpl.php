<?php
/* Smarty version 3.1.33, created on 2019-04-22 06:16:29
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\signin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5cbd401d255d75_33381668',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '74c8ddd253d35f1f0549ff5e4b237e60eb39a318' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\signin.tpl',
      1 => 1554454877,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5cbd401d255d75_33381668 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_21343523255cbd401d2530a9_46494817', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block 'content'} */
class Block_21343523255cbd401d2530a9_46494817 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_21343523255cbd401d2530a9_46494817',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <main>
        <div class="bg_color_2">
            <div class="container margin_60_35">
                <div id="login-2">
                    <h1><?php echo constant("SIGNIN_PLACEHOLDER");?>
</h1>
                    <form method="post" class="ajaxForm" data-loader="loginLoader" data-url="<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
signinConfirm">
                        <div class="box_form clearfix">
                            <div class="box_login">
                                <a onclick="alert('not available!'); return false;" href="#0"
                                   class="social_bt facebook">Login
                                    with Facebook</a>
                                <a onclick="alert('not available!'); return false;" href="#0" class="social_bt google">Login
                                    with Google</a>
                                <a onclick="alert('not available!'); return false;" href="#0"
                                   class="social_bt linkedin">Login
                                    with Linkedin</a>
                            </div>
                            <div class="box_login last">
                                <div id="loginLoader"></div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control"
                                           placeholder="<?php echo constant("SIGNIN_EMAIL");?>
">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" class="form-control"
                                           placeholder="<?php echo constant("SIGNIN_PASSWORD");?>
">
                                    <a href="#0" class="forgot">
                                        <small><?php echo constant("SIGNIN_FORGOT");?>
</small>
                                    </a>
                                </div>
                                <div class="form-group">
                                    <button class="btn_1" type="submit"><?php echo constant("SIGNIN_SUBMIT");?>
</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <p class="text-center link_bright"><?php echo constant("SIGNIN_NOACCOUNT");?>

                        <a href="/signup"><strong><?php echo constant("SIGNUP_SUBMIT");?>
!</strong></a>
                    </p>
                </div>
                <!-- /login -->
            </div>
        </div>
    </main>
    <!-- /main -->
<?php
}
}
/* {/block 'content'} */
}
