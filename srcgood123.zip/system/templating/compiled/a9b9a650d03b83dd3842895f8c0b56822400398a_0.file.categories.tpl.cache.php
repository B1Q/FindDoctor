<?php
/* Smarty version 3.1.33, created on 2019-04-04 17:02:28
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\categories.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca61c846d9f44_73830045',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a9b9a650d03b83dd3842895f8c0b56822400398a' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\categories.tpl',
      1 => 1554390140,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca61c846d9f44_73830045 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->compiled->nocache_hash = '2176527345ca61c846cf4e5_64770828';
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18482607755ca61c846d41c0_46406505', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17294504335ca61c846d9122_69544097', "footer");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "admincp/template/admintemplate.tpl");
}
/* {block "content"} */
class Block_18482607755ca61c846d41c0_46406505 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_18482607755ca61c846d41c0_46406505',
  ),
);
public $nocache = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->cached->hashes['2176527345ca61c846cf4e5_64770828'] = true;
?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> CATEGORIES
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>NAME</th>
                                <th>ORDER</th>
                                <th>FRONT PAGE</th>
                                <th>ACTION</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars[\'categories\']->value, \'category\');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars[\'category\']->value) {
?>/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>

                                <tr id="category<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'id\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
">
                                    <td><?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'id\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
</td>
                                    <td><?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'name\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
</td>
                                    <td><?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'order\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
</td>
                                    <td class="frontPage"><?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'frontpage\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
</td>
                                    <td>
                                        <button class="btn btn-success btnEdit" data-category="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'id\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
"
                                                data-name="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'name\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
" data-order="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'order\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
"
                                                data-frontpage="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'frontpage\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
">EDIT
                                        </button>
                                        <button class="btn btn-danger btnDelete" data-category="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'category\']->value[\'id\'];?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
">DELETE
                                        </button>
                                    </td>
                                </tr>
                            <?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="box_form">
                <div id="addCatLoader"></div>
                <form method="post" class="ajaxForm" data-loader="addCatLoader"
                      data-url="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'siteurl\']->value;?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
adminAddCategory">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>NAME</label>
                                <input type="text" name="categoryName" id="frmcategoryName" class="form-control"
                                       placeholder="Category Name">
                            </div>
                            <div class="form-group">
                                <label>Order</label>
                                <input type="number" name="categoryOrder" id="frmcategoryOrder" class="form-control"
                                       min="0" max="1"
                                       placeholder="Order in the list">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>FrontPage</label>
                                <select class="form-control" id="categoryfrontPage" name="frontPage">
                                    <option value="1">YES</option>
                                    <option value="0" selected>NO</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>ACTION</label><br>
                                <button class="btn btn-primary " style="width:30%" id="btnAddCategory">Add Category
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- Update Modal-->
    <div class="modal fade" id="modalEDIT" tabindex="-1" role="dialog" aria-labelledby="modalEDITLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEDITLabel">EDIT CATEGORY</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" class="ajaxForm" data-loader="updateLoader" id="addCategoryFrm"
                      data-url="<?php echo '/*%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/<?php echo $_smarty_tpl->tpl_vars[\'siteurl\']->value;?>
/*/%%SmartyNocache:2176527345ca61c846cf4e5_64770828%%*/';?>
adminUpdateCategory">
                    <div class="modal-body">
                        <div id="updateLoader"></div>

                        <input type="hidden" value="0" name="categoryID" id="categoryID">
                        <div class="box_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>NAME</label>
                                        <input type="text" id="categoryName" name="categoryName" class="form-control"
                                               placeholder="Category Name">
                                    </div>
                                    <div class="form-group">
                                        <label>Order</label>
                                        <input type="number" id="categoryOrder" name="categoryOrder"
                                               class="form-control"
                                               placeholder="Order in the list">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>FrontPage</label>
                                        <select class="form-control" id="categoryFront" name="frontPage">
                                            <option value="1">YES</option>
                                            <option value="0" selected>NO</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary btnUpdateOrder" type="submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_17294504335ca61c846d9122_69544097 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_17294504335ca61c846d9122_69544097',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
>
        $(function () {
            $('.frontPage').each(function () {
                let val = $(this).html() == "1" ? "YES" : "NO";
                $(this).html(val);
            });

            $('.btnDelete').on('click', function () {
                let categoryID = $(this).data("category");
                
                let categoryData = {categoryID: categoryID}
                
                if (confirm("Are you sure you want to delete the category " + categoryID + "?"))
                    AjaxPost('<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
adminDeleteCategory', categoryData, function (data) {
                        if (data['state'] == "success") {
                            $("#category" + categoryID).remove();
                            alert(data['message']);
                        }
                        else
                            alert(data['message'])
                    });
            });

            $('.btnEdit').on('click', function () {
                let categoryID = $(this).data('category');
                let categoryName = $(this).data('name');
                let categoryOrder = $(this).data('order');
                let categoryFront = $(this).data('front');

                $('#categoryID').val(categoryID);
                $('#categoryName').val(categoryName);
                $('#categoryOrder').val(categoryOrder);
                $('#modalEDIT').modal();
            });

            $('.ajaxForm').bind('success', function (e, id) {
                let name = $('#frmcategoryName').val();
                let order = $('#frmcategoryOrder').val();
                let front = $('#categoryfrontPage').find(':selected').text();

                $('#dataTable').append(' <tr>\n' +
                    '                                    <td>' + id + '</td>\n' +
                    '                                    <td>' + name + '</td>\n' +
                    '                                    <td>' + order + '</td>\n' +
                    '                                    <td class="frontPage">' + front + '</td>\n' +
                    '                                    <td>\n' +
                    '                                        <button class="btn btn-success btnEdit" data-category="' + id + '"\n' +
                    '                                                data-name="' + name + '" data-order="' + order + '"\n' +
                    '                                                data-frontpage="' + front + '">EDIT\n' +
                    '                                        </button>\n' +
                    '                                        <button class="btn btn-danger btnDelete" data-category="' + id + '">DELETE\n' +
                    '                                        </button>\n' +
                    '                                    </td>\n' +
                    '                                </tr>')
            });
        });
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "footer"} */
}
