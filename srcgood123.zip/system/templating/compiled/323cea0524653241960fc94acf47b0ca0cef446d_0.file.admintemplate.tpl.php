<?php
/* Smarty version 3.1.33, created on 2019-04-22 06:15:01
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\template\admintemplate.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5cbd3fc575d866_82055093',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '323cea0524653241960fc94acf47b0ca0cef446d' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\template\\admintemplate.tpl',
      1 => 1554352147,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admincp/template/head.tpl' => 1,
    'file:admincp/template/header.tpl' => 1,
    'file:admincp/template/footer.tpl' => 1,
  ),
),false)) {
function content_5cbd3fc575d866_82055093 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>


<!DOCTYPE html>
<html lang="en">

<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body class="fixed-nav sticky-footer" id="page-top">

<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19095888625cbd3fc575cc38_42465002', "content");
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6849970465cbd3fc575d133_51704187', "footer");
?>

</body>

</html>
<?php }
/* {block "content"} */
class Block_19095888625cbd3fc575cc38_42465002 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_19095888625cbd3fc575cc38_42465002',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_6849970465cbd3fc575d133_51704187 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_6849970465cbd3fc575d133_51704187',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php $_smarty_tpl->_subTemplateRender("file:admincp/template/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
/* {/block "footer"} */
}
