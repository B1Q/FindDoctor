<?php
/* Smarty version 3.1.33, created on 2019-04-04 19:49:31
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\control.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca643ab64fc91_85261583',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b1693b010b052a9e297c88b2ad30aa48c8d7d027' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\control.tpl',
      1 => 1554387098,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:userpanel/orders.tpl' => 1,
    'file:userpanel/editprofile.tpl' => 1,
  ),
),false)) {
function content_5ca643ab64fc91_85261583 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6035688345ca643ab64bc77_59525816', "head");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15438406805ca643ab64cca2_80192063', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18178477235ca643ab64f074_00905885', "footer");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block "head"} */
class Block_6035688345ca643ab64bc77_59525816 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_6035688345ca643ab64bc77_59525816',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link href="<?php echo $_smarty_tpl->tpl_vars['cssPath']->value;?>
blog.css" rel="stylesheet">
<?php
}
}
/* {/block "head"} */
/* {block "content"} */
class Block_15438406805ca643ab64cca2_80192063 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_15438406805ca643ab64cca2_80192063',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <main>
        <div class="main_title">
            <h1><?php echo constant("CONTROL_TITLE");?>
</h1>
        </div>

        <div class="container margin_60">

            <div class="row">
                <div class="col-lg-9">
                    <article class="blog wow fadeIn">
                        <div class="row no-gutters">
                            <div class="col-lg-12 goodtab" id="tabOrders">
                                <?php $_smarty_tpl->_subTemplateRender("file:userpanel/orders.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                            </div>
                            <div class="col-lg-12 goodtab" style="display: none" id="tabProfile">
                                <?php $_smarty_tpl->_subTemplateRender("file:userpanel/editprofile.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                            </div>
                        </div>
                    </article>
                    <!-- /article -->
                </div>
                <!-- /col -->

                <div class="widget">
                    <div class="widget-title">
                        <h4><?php echo constant("CONTROL_CONTROLS");?>
</h4>
                    </div>
                    <div class="switch-field">
                        <input type="radio" id="all" name="type_patient" value="all" checked="">
                        <label class='createiveLabel' style='width: 120px;' for="all"
                               data-tab="tabOrders"><?php echo constant("CONTROL_ORDERSBTN");?>
</label><br>
                        <input type="radio" id="doctors" name="type_patient" value="doctors">
                        <label class='createiveLabel' style="width: 120px;" for="doctors"
                               data-tab="tabProfile"><?php echo constant("CONTROL_EDITPROFILE");?>
</label><br>
                    </div>
                </div>
                <!-- /widget -->


                </aside>
                <!-- /aside -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </main>
    <!-- /main -->
<?php
}
}
/* {/block "content"} */
/* {block "footer"} */
class Block_18178477235ca643ab64f074_00905885 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_18178477235ca643ab64f074_00905885',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
>
        $('.createiveLabel').on('click', function (e) {
            $('.goodtab').hide();
            $('#' + $(this).data("tab")).show();
        });

        $('.btnAbort').on('click', function (e) {
            let name = $(this).data("killname");
            let testid = $(this).data("killid");

            
            let data = {id: testid};
            

            if (confirm("are you sure you want to abort the test '" + name + "'?"))
                AjaxPost('<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
abortTest', data, function (data) {
                    alert(data['message']);
                });
        });
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "footer"} */
}
