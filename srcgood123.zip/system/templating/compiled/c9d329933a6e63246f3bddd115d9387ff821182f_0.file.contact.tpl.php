<?php
/* Smarty version 3.1.33, created on 2019-04-22 06:16:50
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\contact.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5cbd40329f6214_53925734',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c9d329933a6e63246f3bddd115d9387ff821182f' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\contact.tpl',
      1 => 1554255182,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5cbd40329f6214_53925734 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7250602775cbd40329f4188_57451258', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "template/maintemplate.tpl");
}
/* {block 'content'} */
class Block_7250602775cbd40329f4188_57451258 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_7250602775cbd40329f4188_57451258',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <main>
        <!-- /map -->

        <div class="container margin_60_35">
            <div class="row">
                <aside class="col-lg-3 col-md-4">
                    <div id="contact_info">
                        <h3><?php echo constant("CONTACT_INFO");?>
</h3>
                        <p>
                            <?php echo constant("CONTACT_ADDRESS");?>

                        </p>
                        <h4>Get directions</h4>
                        <form action="http://maps.google.com/maps" method="get" target="_blank">
                            <div class="form-group">
                                <input type="text" name="saddr" placeholder="Enter your location"
                                       class="form-control styled">
                                <input type="hidden" name="daddr" value="New York, NY 11430">
                                <!-- Write here your end point -->
                            </div>
                            <input type="submit" value="Get directions" class="btn_1 add_bottom_45">
                        </form>
                        <ul>
                            <li><strong><?php echo constant("CONTACT_ADMINISTRATION");?>
</strong>
                                <a href="tel://003823932342">0038 23932342</a><br><a href="tel://003823932342">admin@findoctor.com</a><br>
                                <small>Monday to Friday 9am - 7pm</small>
                            </li>
                            <li><strong><?php echo constant("CONTACT_GENERALQUESTION");?>
</strong>
                                <a href="tel://003823932342">0038 23932342</a><br><a href="tel://003823932342">questions@findoctor.com</a><br>
                                <p>
                                    <small>Monday to Friday 9am - 7pm</small>
                                </p>
                            </li>
                        </ul>
                    </div>
                </aside>
                <!--/aside -->
                <div class=" col-lg-8 col-md-8 ml-auto">
                    <div class="box_general">
                        <h3>Contact us</h3>
                        <p>
                            Mussum ipsum cacilds, vidis litro abertis.
                        </p>
                        <div>
                            <div id="message-contact"></div>
                            <form method="post" action="assets/contact.php" id="contactform">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="name_contact"
                                                   name="name_contact"
                                                   placeholder="Name">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="lastname_contact"
                                                   name="lastname_contact" placeholder="Last name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="email" id="email_contact" name="email_contact"
                                                   class="form-control"
                                                   placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <input type="text" id="phone_contact" name="phone_contact"
                                                   class="form-control"
                                                   placeholder="Phone number">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                        <textarea rows="5" id="message_contact" name="message_contact"
                                                  class="form-control" style="height:100px;"
                                                  placeholder="Hello world!"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" id="verify_contact" class=" form-control"
                                                   placeholder=" 3 + 1 =">
                                        </div>
                                    </div>
                                </div>
                                <input type="submit" value="Submit" class="btn_1 add_top_20" id="submit-contact">
                            </form>
                        </div>
                        <!-- /col -->
                    </div>
                </div>
                <!-- /col -->
            </div>
            <!-- End row -->
        </div>
        <!-- /container -->
    </main>
    <!-- /main -->
<?php
}
}
/* {/block 'content'} */
}
