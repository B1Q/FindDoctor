<?php
/* Smarty version 3.1.33, created on 2019-04-04 06:54:29
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\template\head.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca58e0566af41_06386557',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd1dc470f91be457982aa4bd0f2e3000c1c16a061' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\template\\head.tpl',
      1 => 1554353668,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca58e0566af41_06386557 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>

<head>
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5487629195ca58e05669262_13150990', "head");
?>

</head>
<?php }
/* {block "head"} */
class Block_5487629195ca58e05669262_13150990 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_5487629195ca58e05669262_13150990',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="Ansonika">
        <base href="/"/>
        <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - Admin dashboard</title>
        <!-- Favicons-->
        <link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/img/favicon.ico" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon"
              href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/img/apple-touch-icon-57x57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72"
              href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/img/apple-touch-icon-72x72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114"
              href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/img/apple-touch-icon-114x114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144"
              href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/img/apple-touch-icon-144x144-precomposed.png">
        <!-- Bootstrap core CSS-->
        <link href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Icon fonts-->
        <link href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet"
              type="text/css">
        <!-- Plugin styles -->
        <link href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
        <!-- Main styles -->
        <link href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/css/admin.css" rel="stylesheet">
        <!-- Your custom styles -->
        <link href="<?php echo $_smarty_tpl->tpl_vars['assetsPath']->value;?>
/adminassets/css/admin.css" rel="stylesheet">
        <!-- All Icons -->
        <link href="<?php echo $_smarty_tpl->tpl_vars['cssPath']->value;?>
icon_fonts/css/all_icons_min.css" rel="stylesheet">

    <?php
}
}
/* {/block "head"} */
}
