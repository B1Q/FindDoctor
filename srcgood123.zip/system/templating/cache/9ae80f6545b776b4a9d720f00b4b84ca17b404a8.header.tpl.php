<?php
/* Smarty version 3.1.33, created on 2019-04-03 03:14:35
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca408fbe7b0c8_07247473',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e8deb8749bd9cba88a4382196bf46ab454470de8' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\header.tpl',
      1 => 1554194030,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5ca408fbe7b0c8_07247473 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="layer"></div>
<!-- Mobile menu overlay mask -->

<div id="preloader">
    <div data-loader="circle-side"></div>
</div>
<!-- End Preload -->

<header class="header_sticky">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-6">
                <div id="logo_home">
                    <h1><a href="/" title="FindDoc good">FindDoc good</a></h1>
                </div>
            </div>
            <nav class="col-lg-9 col-6">
                <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile</span></a>
                <ul id="top_access">
                    <li><a href="/control"><i class="pe-7s-user"></i></a></li>
                    <li><a href="/signup"><i class="pe-7s-add-user"></i></a></li>
                </ul>
                <div class="main-menu">
                    <ul>
                        <li>
                            <a href="/">Home</a>
                        </li>
                        <li>
                            <a href="/about">ABOUT US</a>
                        </li>
                        <li>
                            <a href="/test">TESTS</a>
                        </li>
                        <li><a href="/contact">CONTACT US</a></li>
                    </ul>
                </div>
                <!-- /main-menu -->
            </nav>
        </div>
    </div>
    <!-- /container -->
</header>
<!-- /header --><?php }
}
