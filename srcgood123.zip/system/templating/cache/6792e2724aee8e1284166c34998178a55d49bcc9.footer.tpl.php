<?php
/* Smarty version 3.1.33, created on 2019-04-03 03:14:35
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\template\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca408fbe833b4_11255729',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'be54d67ee937ca5518609d66be998b7633242f4b' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\footer.tpl',
      1 => 1554253677,
      2 => 'file',
    ),
    'e4219bd5141cabceed4cbe5b16e17f246c976061' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\jqueryScripts.tpl',
      1 => 1554253464,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5ca408fbe833b4_11255729 (Smarty_Internal_Template $_smarty_tpl) {
?>
<footer>
    <div class="container margin_60_35">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <p>
                    <a href="index.html" title="Findoctor">
                        <img src="assets/img//logo.png" data-retina="true" alt="" width="163" height="36"
                             class="img-fluid">
                    </a>
                </p>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5>About</h5>
                <ul class="links">
                    <li><a href="#0">About Us</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a href="#0">FAQ</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5>Useful links</h5>
                <ul class="links">
                    <li><a href="#0">Doctors</a></li>
                    <li><a href="#0">Clinics</a></li>
                    <li><a href="#0">Specialization</a></li>
                    <li><a href="signup">Join as a Doctor</a></li>
                    <li><a href="#0">Download App</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5>Contact with Us</h5>
                <ul class="contacts">
                    <li><a href="tel://+201096690560"><i class="icon_mobile"></i> +201096690560</a></li>
                    <li><a href="mailto:ksamkasdf@gmail.com"><i class="icon_mail_alt"></i> ksamkasdf@gmail.com</a></li>
                </ul>
                <div class="follow_us">
                    <h5>Follow us</h5>
                    <ul>
                        <li><a target='_blank' href="https://facebook.com/B1QB0SS"target='_blank' ><i class="social_facebook"></i></a></li>
                        <li><a target='_blank' href="https://twitter.com/B1Q"><i class="social_twitter"></i></a></li>
                        <li><a target='_blank' href="https://linkedin.com"><i class="social_linkedin"></i></a></li>
                        <li><a target='_blank' href="https://instagram.com"><i class="social_instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!--/row-->
        <hr>
        <div class="row">
            <div class="col-md-8">
                <ul id="additional_links">
                    <li><a href="#0">Terms and conditions</a></li>
                    <li><a href="#0">Privacy</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <div id="copy">© 2019 FindDoc</div>
            </div>
        </div>
    </div>
</footer>
<!--/footer-->

<div id="toTop"></div>
<!-- Back to top button -->

<!-- COMMON SCRIPTS -->
<script src="assets/js/jquery-2.2.4.min.js"></script>
<script src="assets/js/common_scripts.min.js"></script>
<script src="assets/js/functions.js"></script>
<script src="assets/js/custom.js"></script>
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" async></script>

<!-- Scripts -->

<script>
    
    $('.ajaxForm').submit(function (e) {
        e.preventDefault();
        const form = $(this);
        $("#" + form.data('loader')).show();
        AjaxLoading(form.data("loader"));
        AjaxPost(form.data("url"), form.serialize(), function (data) {
            let msg = data['message'];
            if (data['state'] == 'success') {
                msg = "<div class='message alert alert-success alert-dismissible'>" + data['message'] + "</div>";

                if (form.data("url").indexOf('signinConfirm') > 0)
                    setTimeout(function (e) {
                        location.reload();
                    }, 2000);
            }
            $("#" + form.data("loader")).html(msg);

            setTimeout(function (e) {
                $("#" + form.data("loader")).hide();
            }, 10000);
            return false;
        });
        RemoveAjaxLoader(form.data("loader"));
        return false;
    });
    
</script>
</body>

</html><?php }
}
