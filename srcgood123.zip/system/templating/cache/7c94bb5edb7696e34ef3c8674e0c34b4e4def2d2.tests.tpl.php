<?php
/* Smarty version 3.1.33, created on 2019-04-04 19:07:41
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\cart\tests.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca639dd6ceb46_84952359',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '56f52b0ea3726d6f7e5e74d738ccf710037dd002' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\cart\\tests.tpl',
      1 => 1554389624,
      2 => 'file',
    ),
    '9890d898631b3932df3052a538a1a36de60dddb2' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\maintemplate.tpl',
      1 => 1554276038,
      2 => 'file',
    ),
    'e15931432cad4da08ec6e6c68d74bba04353a63f' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\head.tpl',
      1 => 1554352181,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5ca639dd6ceb46_84952359 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">


<head>
    
        <title>FindDoc good</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Find easily a doctor and book online an appointment">
        <meta name="author" content="Ansonika">
        <base href="/"/>
        <!-- Favicons-->
        <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/img/apple-touch-icon-57x57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72"
              href="assets/img/apple-touch-icon-72x72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114"
              href="assets/img/apple-touch-icon-114x114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144"
              href="assets/img/apple-touch-icon-144x144-precomposed.png">
        <!-- BASE CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/css/menu.css" rel="stylesheet">
        <link href="assets/css/vendors.css" rel="stylesheet">
        <link href="assets/css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
        <!-- YOUR CUSTOM CSS -->
        <link href="assets/css/custom.css" rel="stylesheet">
    
    <link href="assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

</head>

<body>

<?php $_smarty_tpl->_subTemplateRender("file:template/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



    <main>
        <div class="main_title">
            <h1><?php echo constant("TESTS_TITLE");?>
</h1>
        </div>

        <div class="box_form">
            <div class="row">
                <div class="col-md-2">
                    <h3>CATEGORY</h3>
                    <div class="form-group">
                        <select class="form-control" id="categorySelector">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['categories']->value, 'category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['category']->value) {
?>
                                <option name="<?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
</option>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0"
                           role="grid"
                           aria-describedby="dataTable_info" style="width: 100%;">
                        <thead>
                        <tr role="row">
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="TEST NAME: activate to sort column ascending" style="width: 180px;">TEST
                                NAME
                            </th>
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="REGULAR PRICE: activate to sort column ascending" style="width: 160px;">
                                PRICE
                            </th>
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="REGULAR PRICE: activate to sort column ascending" style="width: 160px;">
                                CATEGORIES
                            </th>
                            <th tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1"
                                aria-label="CART: activate to sort column ascending" style="width: 50px;">
                                CART
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                            <tr role="row" class="even">
                                <td><?php echo $_smarty_tpl->tpl_vars['test']->value['name'];?>
</td>
                                <td id="test<?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
" data-price="<?php echo $_smarty_tpl->tpl_vars['test']->value['price'];?>
"><?php echo $_smarty_tpl->tpl_vars['test']->value['price'];?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['test']->value['category'];?>
</td>
                                <td>
                                    <button id="test<?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
" data-name="<?php echo $_smarty_tpl->tpl_vars['test']->value['name'];?>
" class="btn btn-info cartBtn"
                                            data-test="<?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
">
                                        Add To Cart
                                    </button>
                                </td>
                            </tr>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-4">
                    <div class="box_general_3 booking">
                        <form>
                            <div class="title">
                                <h3>Your booking</h3>
                            </div>
                            <ul class="treatments checkout clearfix">
                                <?php if (count($_smarty_tpl->tpl_vars['cartData']->value) > 0) {?>
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cartData']->value, 'cartItem');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['cartItem']->value) {
?>
                                        <?php if (is_object($_smarty_tpl->tpl_vars['cartItem']->value)) {?>
                                            <li class="checkoutItem" data-cart="<?php echo $_smarty_tpl->tpl_vars['cartItem']->value->id;?>
">
                                                <?php echo $_smarty_tpl->tpl_vars['cartItem']->value->name;?>

                                                <a href="#"><i class="float-right removeItem icon-cancel"
                                                               data-id="<?php echo $_smarty_tpl->tpl_vars['cartItem']->value->id;?>
"></i></a>
                                                <strong class="float-right"><?php echo $_smarty_tpl->tpl_vars['cartItem']->value->price;?>
kd</strong>
                                            </li>
                                        <?php }?>
                                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                <?php }?>
                                <li class="total">
                                    Total <strong class="float-right" id="totalAmount"><?php echo $_smarty_tpl->tpl_vars['cartData']->value['total'];?>
 KD</strong>
                                </li>
                            </ul>
                            <hr>
                            <a href="#" id="btnRequestTest" class="btn_1 full-width">Request tests</a>
                        </form>
                    </div>
                    <!-- /box_general -->
                </div>
            </div>
        </div>
    </main>




    <?php $_smarty_tpl->_subTemplateRender("file:template/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <script src="assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script>
        $(document).ready(function () {
            let table = $('#dataTable').DataTable({
                "pageLength": 5,
                lengthMenu: [[5, 10], [5, 10]]
            });

            RegisterEvents();
            ClearShit();

            $('#dataTable').on('draw.dt', function () {
                RegisterEvents();
                ClearShit();
            });

            $('#categorySelector').on('change', function () {
                table.search($(this).find("option:selected").text());
                table.draw();
            });

            $('#btnRequestTest').on('click', function () {
                AjaxPost('http://localhost/checkout', '', function (data) {
                    let responseCode = data['state'];
                    if (responseCode == 'success') {
                        window.location.href = data['message'];
                    }
                    else
                        alert(data['message']);
                });
                return false;
            });
        });

        function ClearShit() {
            $('.checkoutItem').each(function (e) {
                $('button[data-test="' + $(this).data("cart") + '"]').addClass("disabled");
            });
        }

        function RegisterEvents() {
            $('.cartBtn').off('click');
            $('.cartBtn').on('click', function (e) {
                if ($(this).hasClass("disabled")) return;
                let itemId = $(this).data('test');
                let itemName = $(this).data("name")
                let itemPrice = $('#test' + itemId).data("price");
                let element = $(this);
                
                let itemData = {itemID: itemId}
                

                AjaxPost('http://localhost/addtocart', itemData, function (data) {
                    let responseCode = data['state'];
                    if (responseCode != 'error') {
                        let responseMsg = data['message'];
                        let elementToAdd = "           <li class=\"checkoutItem\" data-cart=" + itemId + ">\n" +
                            "                               " + responseMsg['item']['name'] + "\n" +
                            "                            <a href=\"#\"><i class=\"float-right removeItem icon-cancel\"\n" +
                            "                        data-id=" + itemId + "></i></a>\n" +
                            "                        <strong class=\"float-right\">" + responseMsg['item']['price'] + " KD</strong>\n" +
                            "                            </li>"
                        $('.checkout > .total').before(elementToAdd);
                        // $('.checkout > .total').before("<li>" + responseMsg['item']['name'] + " " +
                        //     "<strong class='float-right'>" + responseMsg['item']['price'] + " KD</strong></li>");
                        $('#totalAmount').html(responseMsg['total'] + " KD");
                        element.addClass('disabled');
                        RegisterEvents();
                    }
                    else
                        alert("Something went wrong while trying to add an item to the cart!");
                });
            });

            $('.removeItem').off('click');
            $('.removeItem').on('click', function (e) {
                
                let itemData = {itemID: $(this).data("id")};
                
                AjaxPost('http://localhost/removefromcart', itemData, function (data) {
                    let responseCode = data['state'];

                    if (responseCode === 'success') {
                        let responseMsg = data['message'];
                        let element = $("#item" + responseMsg['item']);
                        let listElement = $("li[data-cart='" + responseMsg['item'] + "']");

                        element.removeClass('disabled');
                        listElement.remove();
                        $('#totalAmount').html(responseMsg['total'] + " KD");
                    }
                });
                return false;
            });
        }


    </script>

</body>

</html>
<?php }
}
