<?php
/* Smarty version 3.1.33, created on 2019-04-04 19:18:20
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\control.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca63c5ccbd015_78069542',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'b1693b010b052a9e297c88b2ad30aa48c8d7d027' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\control.tpl',
      1 => 1554387098,
      2 => 'file',
    ),
    '9890d898631b3932df3052a538a1a36de60dddb2' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\maintemplate.tpl',
      1 => 1554276038,
      2 => 'file',
    ),
    'e15931432cad4da08ec6e6c68d74bba04353a63f' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\template\\head.tpl',
      1 => 1554398238,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5ca63c5ccbd015_78069542 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">


<head>
    
        <title>FindDoc good</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Find easily a doctor and book online an appointment">
        <meta name="author" content="Ansonika">
        <base href="/"/>
        <!-- Favicons-->
        <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/img/apple-touch-icon-57x57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72"
              href="assets/img/apple-touch-icon-72x72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114"
              href="assets/img/apple-touch-icon-114x114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144"
              href="assets/img/apple-touch-icon-144x144-precomposed.png">
        <!-- BASE CSS -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/css/menu.css" rel="stylesheet">
        <link href="assets/css/vendors.css" rel="stylesheet">
        <link href="assets/css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.3.0/css/flag-icon.min.css"
              integrity="sha256-NkXMfPcpoih3/xWDcrJcAX78pHpfwxkhNj0bAf8AMTs=" crossorigin="anonymous"/>
        <!-- YOUR CUSTOM CSS -->
        <link href="assets/css/custom.css" rel="stylesheet">
    
    <link href="assets/css/blog.css" rel="stylesheet">

</head>

<body>

<?php $_smarty_tpl->_subTemplateRender("file:template/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



    <main>
        <div class="main_title">
            <h1>حسابي</h1>
        </div>

        <div class="container margin_60">

            <div class="row">
                <div class="col-lg-9">
                    <article class="blog wow fadeIn">
                        <div class="row no-gutters">
                            <div class="col-lg-12 goodtab" id="tabOrders">
                                <?php $_smarty_tpl->_subTemplateRender("file:userpanel/orders.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                            </div>
                            <div class="col-lg-12 goodtab" style="display: none" id="tabProfile">
                                <?php $_smarty_tpl->_subTemplateRender("file:userpanel/editprofile.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                            </div>
                        </div>
                    </article>
                    <!-- /article -->
                </div>
                <!-- /col -->

                <div class="widget">
                    <div class="widget-title">
                        <h4>ضوابط</h4>
                    </div>
                    <div class="switch-field">
                        <input type="radio" id="all" name="type_patient" value="all" checked="">
                        <label class='createiveLabel' style='width: 120px;' for="all"
                               data-tab="tabOrders">عرض الطلبات</label><br>
                        <input type="radio" id="doctors" name="type_patient" value="doctors">
                        <label class='createiveLabel' style="width: 120px;" for="doctors"
                               data-tab="tabProfile">تعديل الملف الشخصي</label><br>
                    </div>
                </div>
                <!-- /widget -->


                </aside>
                <!-- /aside -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </main>
    <!-- /main -->




    <?php $_smarty_tpl->_subTemplateRender("file:template/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <script>
        $('.createiveLabel').on('click', function (e) {
            $('.goodtab').hide();
            $('#' + $(this).data("tab")).show();
        });

        $('.btnAbort').on('click', function (e) {
            let name = $(this).data("killname");
            let testid = $(this).data("killid");

            
            let data = {id: testid};
            

            if (confirm("are you sure you want to abort the test '" + name + "'?"))
                AjaxPost('http://localhost/abortTest', data, function (data) {
                    alert(data['message']);
                });
        });
    </script>

</body>

</html>
<?php }
}
