<?php
/* Smarty version 3.1.33, created on 2019-04-04 17:02:28
  from 'D:\Programming\Web Development\PHP\FindDoctor\src\app\Views\admincp\categories.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca61c846dfaf2_52012674',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'a9b9a650d03b83dd3842895f8c0b56822400398a' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\categories.tpl',
      1 => 1554390140,
      2 => 'file',
    ),
    '323cea0524653241960fc94acf47b0ca0cef446d' => 
    array (
      0 => 'D:\\Programming\\Web Development\\PHP\\FindDoctor\\src\\app\\Views\\admincp\\template\\admintemplate.tpl',
      1 => 1554352147,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5ca61c846dfaf2_52012674 (Smarty_Internal_Template $_smarty_tpl) {
?>

<!DOCTYPE html>
<html lang="en">

<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body class="fixed-nav sticky-footer" id="page-top">

<?php $_smarty_tpl->_subTemplateRender("file:admincp/template/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> CATEGORIES
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>NAME</th>
                                <th>ORDER</th>
                                <th>FRONT PAGE</th>
                                <th>ACTION</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['categories']->value, 'category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['category']->value) {
?>
                                <tr id="category<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
">
                                    <td><?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['category']->value['order'];?>
</td>
                                    <td class="frontPage"><?php echo $_smarty_tpl->tpl_vars['category']->value['frontpage'];?>
</td>
                                    <td>
                                        <button class="btn btn-success btnEdit" data-category="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"
                                                data-name="<?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
" data-order="<?php echo $_smarty_tpl->tpl_vars['category']->value['order'];?>
"
                                                data-frontpage="<?php echo $_smarty_tpl->tpl_vars['category']->value['frontpage'];?>
">EDIT
                                        </button>
                                        <button class="btn btn-danger btnDelete" data-category="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
">DELETE
                                        </button>
                                    </td>
                                </tr>
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="box_form">
                <div id="addCatLoader"></div>
                <form method="post" class="ajaxForm" data-loader="addCatLoader"
                      data-url="<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
adminAddCategory">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>NAME</label>
                                <input type="text" name="categoryName" id="frmcategoryName" class="form-control"
                                       placeholder="Category Name">
                            </div>
                            <div class="form-group">
                                <label>Order</label>
                                <input type="number" name="categoryOrder" id="frmcategoryOrder" class="form-control"
                                       min="0" max="1"
                                       placeholder="Order in the list">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>FrontPage</label>
                                <select class="form-control" id="categoryfrontPage" name="frontPage">
                                    <option value="1">YES</option>
                                    <option value="0" selected>NO</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>ACTION</label><br>
                                <button class="btn btn-primary " style="width:30%" id="btnAddCategory">Add Category
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- Update Modal-->
    <div class="modal fade" id="modalEDIT" tabindex="-1" role="dialog" aria-labelledby="modalEDITLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEDITLabel">EDIT CATEGORY</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form method="post" class="ajaxForm" data-loader="updateLoader" id="addCategoryFrm"
                      data-url="<?php echo $_smarty_tpl->tpl_vars['siteurl']->value;?>
adminUpdateCategory">
                    <div class="modal-body">
                        <div id="updateLoader"></div>

                        <input type="hidden" value="0" name="categoryID" id="categoryID">
                        <div class="box_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>NAME</label>
                                        <input type="text" id="categoryName" name="categoryName" class="form-control"
                                               placeholder="Category Name">
                                    </div>
                                    <div class="form-group">
                                        <label>Order</label>
                                        <input type="number" id="categoryOrder" name="categoryOrder"
                                               class="form-control"
                                               placeholder="Order in the list">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>FrontPage</label>
                                        <select class="form-control" id="categoryFront" name="frontPage">
                                            <option value="1">YES</option>
                                            <option value="0" selected>NO</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary btnUpdateOrder" type="submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>




    <?php $_smarty_tpl->_subTemplateRender("file:admincp/template/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <script>
        $(function () {
            $('.frontPage').each(function () {
                let val = $(this).html() == "1" ? "YES" : "NO";
                $(this).html(val);
            });

            $('.btnDelete').on('click', function () {
                let categoryID = $(this).data("category");
                
                let categoryData = {categoryID: categoryID}
                
                if (confirm("Are you sure you want to delete the category " + categoryID + "?"))
                    AjaxPost('http://localhost/adminDeleteCategory', categoryData, function (data) {
                        if (data['state'] == "success") {
                            $("#category" + categoryID).remove();
                            alert(data['message']);
                        }
                        else
                            alert(data['message'])
                    });
            });

            $('.btnEdit').on('click', function () {
                let categoryID = $(this).data('category');
                let categoryName = $(this).data('name');
                let categoryOrder = $(this).data('order');
                let categoryFront = $(this).data('front');

                $('#categoryID').val(categoryID);
                $('#categoryName').val(categoryName);
                $('#categoryOrder').val(categoryOrder);
                $('#modalEDIT').modal();
            });

            $('.ajaxForm').bind('success', function (e, id) {
                let name = $('#frmcategoryName').val();
                let order = $('#frmcategoryOrder').val();
                let front = $('#categoryfrontPage').find(':selected').text();

                $('#dataTable').append(' <tr>\n' +
                    '                                    <td>' + id + '</td>\n' +
                    '                                    <td>' + name + '</td>\n' +
                    '                                    <td>' + order + '</td>\n' +
                    '                                    <td class="frontPage">' + front + '</td>\n' +
                    '                                    <td>\n' +
                    '                                        <button class="btn btn-success btnEdit" data-category="' + id + '"\n' +
                    '                                                data-name="' + name + '" data-order="' + order + '"\n' +
                    '                                                data-frontpage="' + front + '">EDIT\n' +
                    '                                        </button>\n' +
                    '                                        <button class="btn btn-danger btnDelete" data-category="' + id + '">DELETE\n' +
                    '                                        </button>\n' +
                    '                                    </td>\n' +
                    '                                </tr>')
            });
        });
    </script>

</body>

</html>
<?php }
}
